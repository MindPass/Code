

class Personne(object):

    def __init__(self, nom, prenom):
        """

        Returns:
            object:
        """
        self.nom = nom
        self.prenom = prenom

p = Personne("df", "dkjs")
