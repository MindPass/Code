
"""
dic = {"layout": 1, "line": 2}, 2: {"layout": 6, "line": 3}]
print(dic[1]["layout"])
"""

liste = [{"layout": 21215, "line": 1}]
print(liste[0])

liste[0]["new"] = 15
print(liste[0])
